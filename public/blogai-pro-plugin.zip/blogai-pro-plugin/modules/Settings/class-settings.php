<?php
/**
 * Módulo Configurações — página de opções.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Settings {

	public function register_hooks(): void {
		add_action( 'admin_init', [ $this, 'register_settings' ] );
	}

	public function register_settings(): void {
		register_setting( 'blogai_pro_settings_group', 'blogai_pro_settings', [
			'sanitize_callback' => [ $this, 'sanitize' ],
			'default'           => [],
		] );
	}

	public function sanitize( array $input ): array {
		return [
			'api_base_url'     => esc_url_raw( $input['api_base_url'] ?? BLOGAI_PRO_API_BASE_URL ),
			'default_status'   => in_array( $input['default_status'] ?? 'draft', [ 'draft', 'publish' ], true ) ? $input['default_status'] : 'draft',
			'default_category' => (int) ( $input['default_category'] ?? 0 ),
			'seo_integration'  => in_array( $input['seo_integration'] ?? 'auto', [ 'auto', 'yoast', 'rankmath', 'none' ], true ) ? $input['seo_integration'] : 'auto',
			'auto_featured'    => ! empty( $input['auto_featured'] ) ? 1 : 0,
			'plugin_version'   => BLOGAI_PRO_VERSION,
		];
	}
}
