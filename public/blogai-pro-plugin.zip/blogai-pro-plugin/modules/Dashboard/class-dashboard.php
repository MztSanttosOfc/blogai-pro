<?php
/**
 * Módulo Dashboard.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\Dashboard;

use BlogAI_Pro\Modules\API\Client;
use BlogAI_Pro\Modules\Authentication\Auth_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Dashboard {
	public function __construct( private Client $api, private Auth_Manager $auth ) {}

	public function get_stats(): array {
		if ( ! $this->auth->is_authenticated() ) {
			return [];
		}
		$account = $this->api->get_account();
		return is_wp_error( $account ) ? [] : $account;
	}
}
