<?php
/**
 * Módulo Biblioteca — sincroniza artigos da API oficial.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\Library;

use BlogAI_Pro\Modules\API\Client;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Library {

	public function __construct( private Client $api ) {}

	public function register_hooks(): void {
		add_action( 'blogai_pro_sync_library', [ $this, 'sync' ] );
	}

	public function sync(): void {
		$data = $this->api->list_library();
		if ( is_wp_error( $data ) ) {
			return;
		}
		update_option( 'blogai_pro_library_cache', $data, false );
		update_option( 'blogai_pro_last_sync', time(), false );
	}

	public function list(): array {
		$cache = get_option( 'blogai_pro_library_cache', [] );
		return is_array( $cache ) ? $cache : [];
	}
}
