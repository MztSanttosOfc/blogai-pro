<?php
/**
 * Módulo Scheduler — agenda publicações via wp-cron.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\Scheduler;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Scheduler {

	public function register_hooks(): void {
		// Publicação agendada nativa é tratada pelo WP; hook mantido para tarefas customizadas.
	}

	public function schedule_publish( int $post_id, int $timestamp ): void {
		if ( ! wp_next_scheduled( 'blogai_pro_publish_scheduled', [ $post_id ] ) ) {
			wp_schedule_single_event( $timestamp, 'blogai_pro_publish_scheduled', [ $post_id ] );
		}
	}
}
