<?php
/**
 * Enfileira CSS/JS do admin.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\Admin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Assets {

	public function register_hooks(): void {
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
	}

	public function enqueue( string $hook ): void {
		if ( strpos( $hook, 'blogai-pro' ) === false ) {
			return;
		}

		wp_enqueue_style(
			'blogai-pro-admin',
			BLOGAI_PRO_URL . 'assets/css/admin.css',
			[],
			BLOGAI_PRO_VERSION
		);

		wp_enqueue_script(
			'blogai-pro-admin',
			BLOGAI_PRO_URL . 'assets/js/admin.js',
			[ 'wp-api-fetch' ],
			BLOGAI_PRO_VERSION,
			true
		);

		wp_localize_script( 'blogai-pro-admin', 'BlogAIPro', [
			'restUrl'  => esc_url_raw( rest_url( 'blogai-pro/v1' ) ),
			'nonce'    => wp_create_nonce( 'wp_rest' ),
			'adminUrl' => admin_url( 'admin.php' ),
			'i18n'     => [
				'generating' => __( 'Gerando artigo...', 'blogai-pro' ),
				'error'      => __( 'Ocorreu um erro.', 'blogai-pro' ),
				'confirmDel' => __( 'Tem certeza que deseja excluir?', 'blogai-pro' ),
			],
		] );
	}
}
