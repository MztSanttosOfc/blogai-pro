<?php
/**
 * Menu do admin e renderização das páginas.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\Admin;

use BlogAI_Pro\Includes\Helpers;
use BlogAI_Pro\Includes\Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Admin_Menu {

	public function register_hooks(): void {
		add_action( 'admin_menu', [ $this, 'register_menu' ] );
	}

	public function register_menu(): void {
		$cap = 'manage_options';

		add_menu_page(
			__( 'BlogAI Pro', 'blogai-pro' ),
			__( 'BlogAI Pro', 'blogai-pro' ),
			$cap,
			'blogai-pro',
			[ $this, 'render_dashboard' ],
			'dashicons-edit-page',
			26
		);

		add_submenu_page( 'blogai-pro', __( 'Dashboard', 'blogai-pro' ), __( 'Dashboard', 'blogai-pro' ), $cap, 'blogai-pro', [ $this, 'render_dashboard' ] );
		add_submenu_page( 'blogai-pro', __( 'Gerador', 'blogai-pro' ), __( 'Gerador', 'blogai-pro' ), $cap, 'blogai-pro-generator', [ $this, 'render_generator' ] );
		add_submenu_page( 'blogai-pro', __( 'Biblioteca', 'blogai-pro' ), __( 'Biblioteca', 'blogai-pro' ), $cap, 'blogai-pro-library', [ $this, 'render_library' ] );
		add_submenu_page( 'blogai-pro', __( 'Agendamentos', 'blogai-pro' ), __( 'Agendamentos', 'blogai-pro' ), $cap, 'blogai-pro-scheduler', [ $this, 'render_scheduler' ] );
		add_submenu_page( 'blogai-pro', __( 'Configurações', 'blogai-pro' ), __( 'Configurações', 'blogai-pro' ), $cap, 'blogai-pro-settings', [ $this, 'render_settings' ] );
		add_submenu_page( 'blogai-pro', __( 'Conta', 'blogai-pro' ), __( 'Conta', 'blogai-pro' ), $cap, 'blogai-pro-account', [ $this, 'render_account' ] );
	}

	private function guard(): void {
		if ( ! Helpers::current_user_can_manage() ) {
			wp_die( esc_html__( 'Você não tem permissão para acessar esta página.', 'blogai-pro' ) );
		}
	}

	public function render_dashboard(): void {
		$this->guard();
		$auth = Plugin::instance()->auth;
		if ( ! $auth->is_authenticated() ) {
			Helpers::view( 'login' );
			return;
		}
		Helpers::view( 'dashboard', [ 'account' => Plugin::instance()->api->get_account() ] );
	}

	public function render_generator(): void { $this->guard(); Helpers::view( 'generator' ); }
	public function render_library(): void   { $this->guard(); Helpers::view( 'library' ); }
	public function render_scheduler(): void { $this->guard(); Helpers::view( 'scheduler' ); }
	public function render_settings(): void  { $this->guard(); Helpers::view( 'settings' ); }
	public function render_account(): void   { $this->guard(); Helpers::view( 'account', [ 'user' => Plugin::instance()->auth->current_user() ] ); }
}
