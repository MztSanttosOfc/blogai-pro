<?php
/**
 * Rotas REST internas do plugin (namespace blogai-pro/v1).
 * Thin-adapters entre o JS do admin e o cliente da API oficial.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\API;

use BlogAI_Pro\Includes\Plugin;
use BlogAI_Pro\Modules\Authentication\Auth_Manager;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class REST_Controller {

	private const NAMESPACE_V1 = 'blogai-pro/v1';

	public function __construct( private Auth_Manager $auth, private Client $api ) {}

	public function register_hooks(): void {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	public function permissions(): bool {
		return current_user_can( 'manage_options' );
	}

	public function register_routes(): void {
		$ns   = self::NAMESPACE_V1;
		$perm = [ $this, 'permissions' ];

		// Auth.
		register_rest_route( $ns, '/login',   [ 'methods' => 'POST', 'permission_callback' => $perm, 'callback' => [ $this, 'login' ] ] );
		register_rest_route( $ns, '/logout',  [ 'methods' => 'POST', 'permission_callback' => $perm, 'callback' => [ $this, 'logout' ] ] );
		register_rest_route( $ns, '/me',      [ 'methods' => 'GET',  'permission_callback' => $perm, 'callback' => [ $this, 'me' ] ] );
		register_rest_route( $ns, '/refresh', [ 'methods' => 'POST', 'permission_callback' => $perm, 'callback' => [ $this, 'refresh' ] ] );

		// Dashboard.
		register_rest_route( $ns, '/account', [ 'methods' => 'GET', 'permission_callback' => $perm, 'callback' => [ $this, 'account' ] ] );
		register_rest_route( $ns, '/profile', [ 'methods' => 'GET', 'permission_callback' => $perm, 'callback' => [ $this, 'profile' ] ] );
		register_rest_route( $ns, '/credits', [ 'methods' => 'GET', 'permission_callback' => $perm, 'callback' => [ $this, 'credits' ] ] );

		// Artigos.
		register_rest_route( $ns, '/library',        [ 'methods' => 'GET',    'permission_callback' => $perm, 'callback' => [ $this, 'library' ] ] );
		register_rest_route( $ns, '/generate',       [ 'methods' => 'POST',   'permission_callback' => $perm, 'callback' => [ $this, 'generate' ] ] );
		register_rest_route( $ns, '/articles/(?P<id>[^/]+)',         [ 'methods' => 'GET',    'permission_callback' => $perm, 'callback' => [ $this, 'get_article' ] ] );
		register_rest_route( $ns, '/articles/(?P<id>[^/]+)',         [ 'methods' => 'DELETE', 'permission_callback' => $perm, 'callback' => [ $this, 'delete_article' ] ] );
		register_rest_route( $ns, '/articles/(?P<id>[^/]+)/publish', [ 'methods' => 'POST',   'permission_callback' => $perm, 'callback' => [ $this, 'publish_article' ] ] );

		// Agendamento.
		register_rest_route( $ns, '/scheduled',       [ 'methods' => 'GET',    'permission_callback' => $perm, 'callback' => [ $this, 'scheduled_list' ] ] );
		register_rest_route( $ns, '/scheduled',       [ 'methods' => 'POST',   'permission_callback' => $perm, 'callback' => [ $this, 'scheduled_create' ] ] );
		register_rest_route( $ns, '/scheduled/(?P<id>[^/]+)', [ 'methods' => 'DELETE', 'permission_callback' => $perm, 'callback' => [ $this, 'scheduled_cancel' ] ] );

		// SEO / pagamentos.
		register_rest_route( $ns, '/seo/performance',   [ 'methods' => 'GET',  'permission_callback' => $perm, 'callback' => [ $this, 'seo_performance' ] ] );
		register_rest_route( $ns, '/payments/overview', [ 'methods' => 'GET',  'permission_callback' => $perm, 'callback' => [ $this, 'payments_overview' ] ] );
		register_rest_route( $ns, '/payments/pix',      [ 'methods' => 'POST', 'permission_callback' => $perm, 'callback' => [ $this, 'payments_pix' ] ] );
	}

	// -----------------------------------------------------------------
	// Helpers
	// -----------------------------------------------------------------
	private function respond( mixed $res ): WP_REST_Response {
		if ( is_wp_error( $res ) ) {
			$status = (int) ( $res->get_error_data()['status'] ?? 400 );
			return new WP_REST_Response( [ 'ok' => false, 'message' => $res->get_error_message() ], $status );
		}
		return rest_ensure_response( $res );
	}

	// -----------------------------------------------------------------
	// Auth
	// -----------------------------------------------------------------
	public function login( WP_REST_Request $r ): WP_REST_Response {
		$mode = sanitize_key( (string) $r->get_param( 'mode' ) ?: 'password' );
		if ( 'api_key' === $mode ) {
			$res = $this->auth->login_with_api_key( (string) $r->get_param( 'api_key' ) );
		} else {
			$res = $this->auth->login(
				(string) $r->get_param( 'email' ),
				(string) $r->get_param( 'password' )
			);
		}
		return rest_ensure_response( $res );
	}

	public function logout(): WP_REST_Response {
		$this->auth->logout();
		return rest_ensure_response( [ 'ok' => true ] );
	}

	public function refresh(): WP_REST_Response {
		$ok = $this->auth->refresh_now();
		return rest_ensure_response( [ 'ok' => $ok ] );
	}

	public function me(): WP_REST_Response { return $this->respond( $this->api->auth_me() ); }

	// -----------------------------------------------------------------
	public function account(): WP_REST_Response { return $this->respond( $this->api->get_account() ); }
	public function profile(): WP_REST_Response { return $this->respond( $this->api->get_profile() ); }
	public function credits(): WP_REST_Response { return $this->respond( $this->api->get_credits() ); }

	// -----------------------------------------------------------------
	public function library( WP_REST_Request $r ): WP_REST_Response {
		$args = array_filter( [
			'page'   => (int) $r->get_param( 'page' ) ?: null,
			'status' => sanitize_text_field( (string) $r->get_param( 'status' ) ) ?: null,
			'search' => sanitize_text_field( (string) $r->get_param( 'search' ) ) ?: null,
		] );
		return $this->respond( $this->api->list_library( $args ) );
	}

	public function generate( WP_REST_Request $r ): WP_REST_Response {
		$params = [
			'topic'    => sanitize_text_field( (string) $r->get_param( 'topic' ) ),
			'tone'     => sanitize_text_field( (string) $r->get_param( 'tone' ) ),
			'language' => sanitize_text_field( (string) $r->get_param( 'language' ) ?: 'pt-BR' ),
			'length'   => sanitize_text_field( (string) $r->get_param( 'length' ) ?: 'medium' ),
		];
		return $this->respond( $this->api->generate_article( $params ) );
	}

	public function get_article( WP_REST_Request $r ): WP_REST_Response {
		return $this->respond( $this->api->get_article( (string) $r['id'] ) );
	}

	public function delete_article( WP_REST_Request $r ): WP_REST_Response {
		return $this->respond( $this->api->delete_article( (string) $r['id'] ) );
	}

	/**
	 * Publica um artigo. Se provider=wordpress → usa o Publisher local
	 * (cria post nativo). Caso contrário, delega à API oficial.
	 */
	public function publish_article( WP_REST_Request $r ): WP_REST_Response {
		$id       = (string) $r['id'];
		$provider = sanitize_text_field( (string) ( $r->get_param( 'provider' ) ?: 'wordpress' ) );
		$status   = sanitize_text_field( (string) ( $r->get_param( 'status' ) ?: 'draft' ) );

		if ( 'wordpress' === $provider ) {
			$article = $this->api->get_article( $id );
			if ( is_wp_error( $article ) ) { return $this->respond( $article ); }

			$post_id = Plugin::instance()->publisher->publish( (array) $article, [
				'status'             => $status,
				'category_id'        => (int) ( $r->get_param( 'category_id' ) ?: 0 ),
				'tags'               => (array) ( $r->get_param( 'tags' ) ?: [] ),
				'featured_image_url' => (string) ( $r->get_param( 'featured_image_url' ) ?: ( $article['featured_image_url'] ?? '' ) ),
				'publish_at'         => (string) ( $r->get_param( 'publish_at' ) ?: '' ),
			] );
			if ( is_wp_error( $post_id ) ) { return $this->respond( $post_id ); }
			return rest_ensure_response( [
				'ok'      => true,
				'post_id' => (int) $post_id,
				'edit'    => get_edit_post_link( (int) $post_id, 'raw' ),
				'view'    => get_permalink( (int) $post_id ),
			] );
		}

		return $this->respond( $this->api->publish_article( $id, [ 'provider' => $provider, 'status' => $status ] ) );
	}

	// -----------------------------------------------------------------
	public function scheduled_list(): WP_REST_Response { return $this->respond( $this->api->list_scheduled() ); }

	public function scheduled_create( WP_REST_Request $r ): WP_REST_Response {
		$params = [
			'article_id' => sanitize_text_field( (string) $r->get_param( 'article_id' ) ),
			'publish_at' => sanitize_text_field( (string) $r->get_param( 'publish_at' ) ),
			'provider'   => sanitize_text_field( (string) $r->get_param( 'provider' ) ?: 'wordpress' ),
		];
		return $this->respond( $this->api->schedule_post( $params ) );
	}

	public function scheduled_cancel( WP_REST_Request $r ): WP_REST_Response {
		return $this->respond( $this->api->cancel_scheduled( (string) $r['id'] ) );
	}

	// -----------------------------------------------------------------
	public function seo_performance(): WP_REST_Response   { return $this->respond( $this->api->seo_performance() ); }
	public function payments_overview(): WP_REST_Response { return $this->respond( $this->api->payments_overview() ); }

	public function payments_pix( WP_REST_Request $r ): WP_REST_Response {
		$params = [
			'plan_id' => sanitize_text_field( (string) $r->get_param( 'plan_id' ) ),
			'amount'  => (float) $r->get_param( 'amount' ),
		];
		return $this->respond( $this->api->create_pix( $params ) );
	}
}
