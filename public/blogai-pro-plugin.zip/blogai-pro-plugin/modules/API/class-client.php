<?php
/**
 * Cliente HTTP oficial do BlogAI Pro.
 *
 * Autenticação (v1):
 *  - POST /auth/login   (email, password)          → tokens
 *  - POST /auth/refresh (refresh_token)            → novos tokens
 *  - GET  /auth/me      (Bearer)                   → identidade
 *
 * Envelope de resposta padrão: { success, data, meta } — request() já
 * desempacota "data" para os módulos consumidores.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\API;

use BlogAI_Pro\Includes\Helpers;
use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Client {

	private string $base_url;

	/** Evita loop de refresh dentro de uma mesma requisição. */
	private bool $refreshing = false;

	public function __construct() {
		$this->base_url = untrailingslashit(
			(string) Helpers::get_setting( 'api_base_url', BLOGAI_PRO_API_BASE_URL )
		);
	}

	// =====================================================================
	// AUTH
	// =====================================================================

	public function login( string $email, string $password ): array|WP_Error {
		return $this->request( 'POST', '/auth/login', [
			'body'    => [ 'email' => $email, 'password' => $password ],
			'no_auth' => true,
		] );
	}

	public function refresh_token( string $refresh_token ): array|WP_Error {
		return $this->request( 'POST', '/auth/refresh', [
			'body'    => [ 'refresh_token' => $refresh_token ],
			'no_auth' => true,
			'no_retry'=> true, // nunca tenta refresh em cima do refresh.
		] );
	}

	public function auth_me( ?string $token = null ): array|WP_Error {
		return $this->get( '/auth/me', [], $token );
	}

	// =====================================================================
	// PROFILE / CREDITS
	// =====================================================================

	public function get_profile(): array|WP_Error { return $this->get( '/profile' ); }
	public function get_credits(): array|WP_Error { return $this->get( '/credits' ); }

	public function get_account(): array|WP_Error {
		$profile = $this->get_profile();
		$credits = $this->get_credits();
		if ( is_wp_error( $profile ) ) { return $profile; }
		if ( is_wp_error( $credits ) ) { return $credits; }
		return [
			'plan'               => $profile['plan'] ?? '—',
			'credits'            => (int) ( $credits['balance'] ?? $profile['credits'] ?? 0 ),
			'credits_used'       => (int) ( $credits['used'] ?? 0 ),
			'articles_generated' => (int) ( $profile['articles_generated'] ?? 0 ),
			'articles_published' => (int) ( $profile['articles_published'] ?? 0 ),
			'renews_at'          => $profile['renews_at'] ?? null,
		];
	}

	// =====================================================================
	// ARTICLES
	// =====================================================================

	public function list_articles( array $args = [] ): array|WP_Error { return $this->get( '/articles', $args ); }
	public function get_article( string $id ): array|WP_Error         { return $this->get( '/articles/' . rawurlencode( $id ) ); }
	public function generate_article( array $params ): array|WP_Error { return $this->post( '/articles', $params ); }
	public function analyze_topic( array $params ): array|WP_Error    { return $this->post( '/articles/analyze', $params ); }
	public function delete_article( string $id ): array|WP_Error      { return $this->request( 'DELETE', '/articles/' . rawurlencode( $id ) ); }
	public function update_article( string $id, array $data ): array|WP_Error {
		return $this->request( 'PATCH', '/articles/' . rawurlencode( $id ), [ 'body' => $data ] );
	}
	public function publish_article( string $id, array $params = [] ): array|WP_Error {
		return $this->post( '/articles/' . rawurlencode( $id ) . '/publish', $params );
	}

	public function list_library( array $args = [] ): array|WP_Error {
		$res = $this->list_articles( $args );
		if ( is_wp_error( $res ) ) { return $res; }
		return [
			'items' => $res['items'] ?? $res['data'] ?? [],
			'total' => (int) ( $res['total'] ?? $res['meta']['total'] ?? 0 ),
		];
	}

	public function duplicate_article( string $id ): array|WP_Error {
		return new WP_Error( 'blogai_pro_not_implemented', __( 'Duplicação de artigos aguardando endpoint oficial.', 'blogai-pro' ) );
	}

	// =====================================================================
	// SCHEDULING
	// =====================================================================

	public function list_scheduled(): array|WP_Error { return $this->get( '/scheduling' ); }
	public function schedule_post( array $params ): array|WP_Error { return $this->post( '/scheduling', $params ); }
	public function reschedule_post( string $id, array $params ): array|WP_Error {
		return $this->request( 'PATCH', '/scheduling/' . rawurlencode( $id ), [ 'body' => $params ] );
	}
	public function cancel_scheduled( string $id ): array|WP_Error {
		return $this->request( 'DELETE', '/scheduling/' . rawurlencode( $id ) );
	}
	public function scheduled_logs( string $id ): array|WP_Error {
		return $this->get( '/scheduling/' . rawurlencode( $id ) . '/logs' );
	}

	// =====================================================================
	// SEO / PAYMENTS / BLOGGER (inalterados)
	// =====================================================================

	public function seo_performance( array $args = [] ): array|WP_Error { return $this->get( '/seo/performance', $args ); }
	public function create_pix( array $params ): array|WP_Error         { return $this->post( '/payments/pix', $params ); }
	public function payment_status( string $id ): array|WP_Error        { return $this->get( '/payments/' . rawurlencode( $id ) . '/status' ); }
	public function payments_overview(): array|WP_Error                 { return $this->get( '/payments/overview' ); }
	public function blogger_status(): array|WP_Error                    { return $this->get( '/blogger/status' ); }
	public function blogger_auth_url(): array|WP_Error                  { return $this->get( '/blogger/auth-url' ); }
	public function blogger_blogs(): array|WP_Error                     { return $this->get( '/blogger/blogs' ); }
	public function blogger_select( string $blog_id ): array|WP_Error   { return $this->post( '/blogger/select', [ 'blog_id' => $blog_id ] ); }
	public function blogger_disconnect(): array|WP_Error                { return $this->post( '/blogger/disconnect' ); }

	// =====================================================================
	// HTTP baixo nível
	// =====================================================================

	private function get( string $endpoint, array $query = [], ?string $token = null ): array|WP_Error {
		if ( ! empty( $query ) ) {
			$endpoint .= ( str_contains( $endpoint, '?' ) ? '&' : '?' ) . http_build_query( $query );
		}
		$args = [];
		if ( null !== $token ) { $args['token'] = $token; }
		return $this->request( 'GET', $endpoint, $args );
	}

	private function post( string $endpoint, array $body = [], ?string $token = null ): array|WP_Error {
		$args = [ 'body' => $body ];
		if ( null !== $token ) { $args['token'] = $token; }
		return $this->request( 'POST', $endpoint, $args );
	}

	/**
	 * @param array $args {
	 *   body?:    array<string,mixed>,
	 *   token?:   string (força um Bearer específico),
	 *   no_auth?: bool   (não envia Authorization),
	 *   no_retry?:bool   (desabilita auto-refresh em 401),
	 * }
	 */
	public function request( string $method, string $endpoint, array $args = [] ): array|WP_Error {
		$url = $this->base_url . '/' . ltrim( $endpoint, '/' );

		$headers = [
			'Accept'        => 'application/json',
			'Content-Type'  => 'application/json',
			'X-Plugin'      => 'blogai-pro-wp/' . BLOGAI_PRO_VERSION,
			'X-Plugin-Site' => home_url(),
		];

		if ( empty( $args['no_auth'] ) ) {
			$auth = (string) ( $args['token'] ?? get_option( 'blogai_pro_auth_token', '' ) );
			if ( '' !== $auth ) {
				$headers['Authorization'] = 'Bearer ' . $auth;
			}
		}

		$response = wp_remote_request( $url, [
			'method'  => strtoupper( $method ),
			'timeout' => 30,
			'headers' => $headers,
			'body'    => isset( $args['body'] ) ? wp_json_encode( $args['body'] ) : null,
		] );

		if ( is_wp_error( $response ) ) {
			Helpers::log( 'API request error', [ 'endpoint' => $endpoint, 'error' => $response->get_error_message() ] );
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$raw  = wp_remote_retrieve_body( $response );
		$body = json_decode( $raw, true );

		// ---- 401: tenta refresh automático uma única vez ----------------
		if ( 401 === $code && empty( $args['no_retry'] ) && empty( $args['no_auth'] ) && ! $this->refreshing ) {
			if ( 'password' === (string) get_option( 'blogai_pro_auth_mode', 'password' ) ) {
				$refresh = (string) get_option( 'blogai_pro_refresh_token', '' );
				if ( '' !== $refresh ) {
					$this->refreshing = true;
					$new              = $this->refresh_token( $refresh );
					$this->refreshing = false;
					if ( ! is_wp_error( $new ) && ! empty( $new['access_token'] ) ) {
						update_option( 'blogai_pro_auth_token', (string) $new['access_token'], false );
						update_option( 'blogai_pro_refresh_token', (string) ( $new['refresh_token'] ?? $refresh ), false );
						$exp = isset( $new['expires_at'] ) ? (int) $new['expires_at'] : time() + (int) ( $new['expires_in'] ?? 3600 );
						update_option( 'blogai_pro_token_expires_at', $exp, false );
						$args['no_retry'] = true;
						unset( $args['token'] );
						return $this->request( $method, $endpoint, $args );
					}
				}
			}
			// Refresh indisponível — limpa sessão.
			delete_option( 'blogai_pro_auth_token' );
			delete_option( 'blogai_pro_refresh_token' );
			delete_option( 'blogai_pro_token_expires_at' );
			return new WP_Error( 'blogai_pro_unauthorized', __( 'Sessão expirada. Faça login novamente.', 'blogai-pro' ), [ 'status' => 401 ] );
		}

		if ( $code >= 400 ) {
			$msg = is_array( $body ) ? ( $body['error']['message'] ?? $body['message'] ?? __( 'Erro na API.', 'blogai-pro' ) ) : __( 'Erro na API.', 'blogai-pro' );
			return new WP_Error( 'blogai_pro_api_error', $msg, [ 'status' => $code, 'response' => $body ] );
		}

		if ( ! is_array( $body ) ) {
			return [];
		}

		// Envelope oficial: { success, data, meta }.
		if ( array_key_exists( 'data', $body ) ) {
			$data = is_array( $body['data'] ) ? $body['data'] : [ 'value' => $body['data'] ];
			if ( isset( $body['meta'] ) ) { $data['meta'] = $body['meta']; }
			return $data;
		}

		return $body;
	}
}
