<?php
/**
 * Módulo Publisher — cria posts nativos do WordPress a partir de artigos do BlogAI Pro.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\Publisher;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Publisher {

	public function register_hooks(): void {
		add_action( 'blogai_pro_publish_scheduled', [ $this, 'process_scheduled' ], 10, 1 );
	}

	/**
	 * Publica ou salva rascunho.
	 *
	 * @param array $article Estrutura vinda da API do BlogAI Pro.
	 * @param array $opts    ['status','category_id','tags','featured_image_url','publish_at']
	 */
	public function publish( array $article, array $opts = [] ): int|\WP_Error {
		$status = in_array( $opts['status'] ?? 'draft', [ 'draft', 'publish', 'future' ], true )
			? $opts['status'] : 'draft';

		$postarr = [
			'post_title'   => sanitize_text_field( $article['title'] ?? '' ),
			'post_content' => wp_kses_post( $article['content'] ?? '' ),
			'post_excerpt' => sanitize_textarea_field( $article['excerpt'] ?? '' ),
			'post_status'  => $status,
			'post_type'    => 'post',
		];

		if ( 'future' === $status && ! empty( $opts['publish_at'] ) ) {
			$postarr['post_date']     = gmdate( 'Y-m-d H:i:s', (int) strtotime( (string) $opts['publish_at'] ) );
			$postarr['post_date_gmt'] = $postarr['post_date'];
		}

		if ( ! empty( $opts['category_id'] ) ) {
			$postarr['post_category'] = [ (int) $opts['category_id'] ];
		}

		$post_id = wp_insert_post( $postarr, true );
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		if ( ! empty( $opts['tags'] ) && is_array( $opts['tags'] ) ) {
			wp_set_post_tags( $post_id, array_map( 'sanitize_text_field', $opts['tags'] ) );
		}

		if ( ! empty( $opts['featured_image_url'] ) ) {
			$this->attach_featured_image( $post_id, (string) $opts['featured_image_url'] );
		}

		// SEO: delega ao SEO_Manager via ação.
		do_action( 'blogai_pro_after_publish', $post_id, $article, $opts );

		return $post_id;
	}

	private function attach_featured_image( int $post_id, string $url ): void {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$attachment_id = media_sideload_image( esc_url_raw( $url ), $post_id, null, 'id' );
		if ( ! is_wp_error( $attachment_id ) ) {
			set_post_thumbnail( $post_id, (int) $attachment_id );
		}
	}

	public function process_scheduled( int $post_id ): void {
		// Placeholder — publicações agendadas nativas são tratadas pelo WordPress.
		unset( $post_id );
	}
}
