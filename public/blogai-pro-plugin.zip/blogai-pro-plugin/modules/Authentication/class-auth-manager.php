<?php
/**
 * Autenticação com a API oficial do BlogAI Pro.
 *
 * A partir da v1.0.1 o plugin usa e-mail e senha via
 * POST /api/v1/auth/login  →  { access_token, refresh_token, expires_in, user }
 * e renova automaticamente através de
 * POST /api/v1/auth/refresh →  { access_token, refresh_token, expires_in }
 *
 * Compatibilidade: usuários que preferirem podem colar uma API Key
 * (bap_live_...) — nesse modo o refresh não se aplica.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\Authentication;

use BlogAI_Pro\Modules\API\Client;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Auth_Manager {

	public function __construct( private Client $api ) {}

	public function register_hooks(): void {
		add_action( 'blogai_pro_refresh_token', [ $this, 'maybe_refresh_token' ] );
	}

	public function is_authenticated(): bool {
		return (bool) get_option( 'blogai_pro_auth_token' );
	}

	public function current_user(): array {
		return (array) get_option( 'blogai_pro_user', [] );
	}

	public function auth_mode(): string {
		return (string) get_option( 'blogai_pro_auth_mode', 'password' );
	}

	/**
	 * Login com e-mail e senha (endpoint oficial).
	 */
	public function login( string $email, string $password ): array {
		$email    = sanitize_email( trim( $email ) );
		$password = (string) $password;
		if ( '' === $email || '' === $password ) {
			return [ 'ok' => false, 'message' => __( 'Informe e-mail e senha.', 'blogai-pro' ) ];
		}

		$res = $this->api->login( $email, $password );
		if ( is_wp_error( $res ) ) {
			return [ 'ok' => false, 'message' => $res->get_error_message() ];
		}

		$this->store_session( $res, 'password' );
		return [ 'ok' => true, 'user' => (array) ( $res['user'] ?? [] ) ];
	}

	/**
	 * Login por API Key (bap_live_...) — mantém compatibilidade com integrações.
	 */
	public function login_with_api_key( string $token ): array {
		$token = trim( $token );
		if ( '' === $token ) {
			return [ 'ok' => false, 'message' => __( 'Informe a API Key.', 'blogai-pro' ) ];
		}

		$res = $this->api->auth_me( $token );
		if ( is_wp_error( $res ) ) {
			return [ 'ok' => false, 'message' => $res->get_error_message() ];
		}

		update_option( 'blogai_pro_auth_token', $token, false );
		update_option( 'blogai_pro_refresh_token', '', false );
		update_option( 'blogai_pro_token_expires_at', 0, false );
		update_option( 'blogai_pro_auth_mode', 'api_key', false );
		update_option( 'blogai_pro_user', (array) ( $res['user'] ?? $res ), false );

		return [ 'ok' => true, 'user' => (array) ( $res['user'] ?? $res ) ];
	}

	public function logout(): void {
		delete_option( 'blogai_pro_auth_token' );
		delete_option( 'blogai_pro_refresh_token' );
		delete_option( 'blogai_pro_token_expires_at' );
		delete_option( 'blogai_pro_auth_mode' );
		delete_option( 'blogai_pro_user' );
	}

	/**
	 * Cron: renova o access_token quando faltar menos de 5 minutos
	 * para expirar. Silenciosamente ignora quando não há refresh_token
	 * (modo API Key) ou quando não estamos logados.
	 */
	public function maybe_refresh_token(): void {
		if ( 'password' !== $this->auth_mode() ) {
			return;
		}
		$refresh = (string) get_option( 'blogai_pro_refresh_token', '' );
		if ( '' === $refresh ) {
			return;
		}
		$expires = (int) get_option( 'blogai_pro_token_expires_at', 0 );
		if ( $expires > 0 && ( $expires - time() ) > 5 * MINUTE_IN_SECONDS ) {
			return;
		}
		$this->refresh_now();
	}

	/**
	 * Força a renovação imediata (chamado pelo Client em 401 também).
	 */
	public function refresh_now(): bool {
		$refresh = (string) get_option( 'blogai_pro_refresh_token', '' );
		if ( '' === $refresh ) {
			return false;
		}
		$res = $this->api->refresh_token( $refresh );
		if ( is_wp_error( $res ) ) {
			return false;
		}
		$this->store_session( $res, 'password' );
		return true;
	}

	private function store_session( array $res, string $mode ): void {
		$access  = (string) ( $res['access_token'] ?? '' );
		$refresh = (string) ( $res['refresh_token'] ?? '' );
		$expires = isset( $res['expires_at'] )
			? (int) $res['expires_at']
			: time() + (int) ( $res['expires_in'] ?? 3600 );

		if ( '' !== $access ) {
			update_option( 'blogai_pro_auth_token', $access, false );
		}
		update_option( 'blogai_pro_refresh_token', $refresh, false );
		update_option( 'blogai_pro_token_expires_at', $expires, false );
		update_option( 'blogai_pro_auth_mode', $mode, false );
		if ( ! empty( $res['user'] ) ) {
			update_option( 'blogai_pro_user', (array) $res['user'], false );
		}
	}
}
