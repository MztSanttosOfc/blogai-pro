<?php
/**
 * Módulo SEO — integra com Yoast e Rank Math e cai para post meta próprio.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\SEO;

use BlogAI_Pro\Includes\Helpers;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class SEO_Manager {

	public function register_hooks(): void {
		add_action( 'blogai_pro_after_publish', [ $this, 'apply_seo' ], 10, 3 );
	}

	public function apply_seo( int $post_id, array $article, array $opts ): void {
		$seo = $article['seo'] ?? [];
		if ( ! $seo ) {
			return;
		}

		$mode = (string) Helpers::get_setting( 'seo_integration', 'auto' );

		$title       = sanitize_text_field( $seo['title'] ?? '' );
		$description = sanitize_text_field( $seo['description'] ?? '' );
		$slug        = sanitize_title( $seo['slug'] ?? '' );
		$og_image    = esc_url_raw( $seo['og_image'] ?? '' );

		if ( $slug ) {
			wp_update_post( [ 'ID' => $post_id, 'post_name' => $slug ] );
		}

		$use_yoast    = ( 'yoast' === $mode ) || ( 'auto' === $mode && defined( 'WPSEO_VERSION' ) );
		$use_rankmath = ( 'rankmath' === $mode ) || ( 'auto' === $mode && class_exists( 'RankMath' ) );

		if ( $use_yoast ) {
			update_post_meta( $post_id, '_yoast_wpseo_title', $title );
			update_post_meta( $post_id, '_yoast_wpseo_metadesc', $description );
			update_post_meta( $post_id, '_yoast_wpseo_opengraph-image', $og_image );
		}

		if ( $use_rankmath ) {
			update_post_meta( $post_id, 'rank_math_title', $title );
			update_post_meta( $post_id, 'rank_math_description', $description );
			update_post_meta( $post_id, 'rank_math_facebook_image', $og_image );
		}

		// Meta próprio como fallback.
		update_post_meta( $post_id, '_blogai_pro_seo', [
			'title'       => $title,
			'description' => $description,
			'og_image'    => $og_image,
		] );
	}
}
