<?php
/**
 * Módulo Gerador de Artigos.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Modules\Generator;

use BlogAI_Pro\Modules\API\Client;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Generator {

	public function __construct( private Client $api ) {}

	public function register_hooks(): void {
		// Placeholder para futuras integrações (ex: bloco Gutenberg).
	}

	public function generate( array $params ): array {
		$res = $this->api->generate_article( $params );
		return is_wp_error( $res ) ? [] : $res;
	}
}
