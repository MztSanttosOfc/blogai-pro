/* BlogAI Pro — admin scripts (v1.0.1).
 * Consome as rotas internas /blogai-pro/v1 (thin adapters da API oficial).
 */
(function () {
	'use strict';
	const { restUrl, nonce, i18n } = window.BlogAIPro || {};

	async function api(path, options = {}) {
		const res = await fetch(restUrl + path, {
			method: options.method || 'GET',
			headers: {
				'Content-Type': 'application/json',
				'X-WP-Nonce': nonce,
			},
			body: options.body ? JSON.stringify(options.body) : undefined,
		});
		let data = null;
		try { data = await res.json(); } catch (e) { /* noop */ }
		if (!res.ok) {
			const msg = (data && data.message) || 'HTTP ' + res.status;
			throw new Error(msg);
		}
		return data || {};
	}

	// ---- Tabs de login (password ↔ api key) ------------------------------
	document.querySelectorAll('.blogai-pro-tab').forEach((tab) => {
		tab.addEventListener('click', () => {
			const target = tab.dataset.target;
			document.querySelectorAll('.blogai-pro-tab').forEach((t) => {
				const active = t === tab;
				t.classList.toggle('is-active', active);
				t.setAttribute('aria-selected', active ? 'true' : 'false');
			});
			document.querySelectorAll('form[data-tab]').forEach((f) => {
				f.hidden = f.dataset.tab !== target;
			});
		});
	});

	function bindLoginForm(formId, payloadFn) {
		const form = document.getElementById(formId);
		if (!form) return;
		const msg = form.querySelector('.blogai-pro-form__message');
		form.addEventListener('submit', async (e) => {
			e.preventDefault();
			msg.className = 'blogai-pro-form__message';
			msg.textContent = '';
			const fd = new FormData(form);
			try {
				const r = await api('/login', { method: 'POST', body: payloadFn(fd) });
				if (r && r.ok) {
					window.location.reload();
				} else {
					msg.classList.add('blogai-pro-form__message--err');
					msg.textContent = (r && r.message) || i18n.error;
				}
			} catch (err) {
				msg.classList.add('blogai-pro-form__message--err');
				msg.textContent = err.message || i18n.error;
			}
		});
	}

	bindLoginForm('blogai-pro-login-form', (fd) => ({
		mode: 'password',
		email: fd.get('email'),
		password: fd.get('password'),
	}));
	bindLoginForm('blogai-pro-login-form-key', (fd) => ({
		mode: 'api_key',
		api_key: fd.get('api_key'),
	}));

	// ---- Logout ---------------------------------------------------------
	const logoutBtn = document.getElementById('blogai-pro-logout');
	if (logoutBtn) {
		logoutBtn.addEventListener('click', async () => {
			try { await api('/logout', { method: 'POST' }); } catch (e) { /* noop */ }
			window.location.reload();
		});
	}

	// ---- Generator ------------------------------------------------------
	const genForm = document.getElementById('blogai-pro-generator-form');
	if (genForm) {
		const preview = document.getElementById('blogai-pro-preview');
		const actions = document.getElementById('blogai-pro-preview-actions');
		genForm.addEventListener('submit', async (e) => {
			e.preventDefault();
			preview.innerHTML = '<p class="blogai-pro-muted">' + i18n.generating + '</p>';
			actions.hidden = true;
			const fd = new FormData(genForm);
			try {
				const article = await api('/generate', {
					method: 'POST',
					body: Object.fromEntries(fd.entries()),
				});
				preview.innerHTML =
					'<h3></h3><div></div>';
				preview.querySelector('h3').textContent = article.title || '';
				preview.querySelector('div').innerHTML = article.content || '';
				actions.hidden = false;
				actions.dataset.articleId = article.id || '';
			} catch (err) {
				preview.innerHTML = '<p class="blogai-pro-form__message--err"></p>';
				preview.querySelector('p').textContent = err.message || i18n.error;
			}
		});
	}

	// ---- Library --------------------------------------------------------
	const libraryTbody = document.getElementById('blogai-pro-library-tbody');
	function td(text) { const c = document.createElement('td'); c.textContent = text == null ? '' : String(text); return c; }
	async function loadLibrary() {
		if (!libraryTbody) return;
		libraryTbody.innerHTML = '';
		const loading = document.createElement('tr');
		const tdl = document.createElement('td');
		tdl.colSpan = 4;
		tdl.className = 'blogai-pro-muted';
		tdl.textContent = i18n.generating || 'Carregando...';
		loading.appendChild(tdl);
		libraryTbody.appendChild(loading);
		try {
			const data = await api('/library');
			libraryTbody.innerHTML = '';
			const items = (data && data.items) || [];
			if (!items.length) {
				const tr = document.createElement('tr');
				const c = document.createElement('td');
				c.colSpan = 4; c.className = 'blogai-pro-muted'; c.textContent = 'Vazio';
				tr.appendChild(c); libraryTbody.appendChild(tr);
				return;
			}
			items.forEach((it) => {
				const tr = document.createElement('tr');
				tr.appendChild(td(it.title));
				tr.appendChild(td(it.status));
				tr.appendChild(td(it.updated_at));
				const acts = document.createElement('td');
				['edit','duplicate','delete'].forEach((action) => {
					const b = document.createElement('button');
					b.className = 'button';
					b.dataset.action = action;
					b.dataset.id = it.id || '';
					b.textContent = action === 'edit' ? 'Editar' : action === 'duplicate' ? 'Duplicar' : 'Excluir';
					acts.appendChild(b); acts.appendChild(document.createTextNode(' '));
				});
				tr.appendChild(acts);
				libraryTbody.appendChild(tr);
			});
		} catch (err) {
			libraryTbody.innerHTML = '';
			const tr = document.createElement('tr');
			const c = document.createElement('td');
			c.colSpan = 4; c.className = 'blogai-pro-form__message--err';
			c.textContent = err.message || i18n.error;
			tr.appendChild(c); libraryTbody.appendChild(tr);
		}
	}
	loadLibrary();
	const syncBtn = document.getElementById('blogai-pro-sync');
	if (syncBtn) syncBtn.addEventListener('click', loadLibrary);
})();
