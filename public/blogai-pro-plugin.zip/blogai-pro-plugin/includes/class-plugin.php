<?php
/**
 * Classe principal (Singleton) que inicializa todos os módulos.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Includes;

use BlogAI_Pro\Modules\Admin\Admin_Menu;
use BlogAI_Pro\Modules\Admin\Assets;
use BlogAI_Pro\Modules\API\Client;
use BlogAI_Pro\Modules\API\REST_Controller;
use BlogAI_Pro\Modules\Authentication\Auth_Manager;
use BlogAI_Pro\Modules\Dashboard\Dashboard;
use BlogAI_Pro\Modules\Generator\Generator;
use BlogAI_Pro\Modules\Library\Library;
use BlogAI_Pro\Modules\Publisher\Publisher;
use BlogAI_Pro\Modules\SEO\SEO_Manager;
use BlogAI_Pro\Modules\Scheduler\Scheduler;
use BlogAI_Pro\Modules\Settings\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	private static ?Plugin $instance = null;

	public Client $api;
	public Auth_Manager $auth;
	public Admin_Menu $admin_menu;
	public Assets $assets;
	public Dashboard $dashboard;
	public Generator $generator;
	public Library $library;
	public Publisher $publisher;
	public SEO_Manager $seo;
	public Scheduler $scheduler;
	public Settings $settings;
	public REST_Controller $rest;

	public static function instance(): Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->api        = new Client();
		$this->auth       = new Auth_Manager( $this->api );
		$this->settings   = new Settings();
		$this->dashboard  = new Dashboard( $this->api, $this->auth );
		$this->generator  = new Generator( $this->api );
		$this->library    = new Library( $this->api );
		$this->publisher  = new Publisher();
		$this->seo        = new SEO_Manager();
		$this->scheduler  = new Scheduler();
		$this->admin_menu = new Admin_Menu();
		$this->assets     = new Assets();
		$this->rest       = new REST_Controller( $this->auth, $this->api );
	}

	public function run(): void {
		$this->auth->register_hooks();
		$this->settings->register_hooks();
		$this->admin_menu->register_hooks();
		$this->assets->register_hooks();
		$this->generator->register_hooks();
		$this->library->register_hooks();
		$this->publisher->register_hooks();
		$this->seo->register_hooks();
		$this->scheduler->register_hooks();
		$this->rest->register_hooks();
	}

	private function __clone() {}
	public function __wakeup() {}
}
