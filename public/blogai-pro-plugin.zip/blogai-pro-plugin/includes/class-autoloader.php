<?php
/**
 * Autoloader PSR-4 simples.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Autoloader {

	public static function register(): void {
		spl_autoload_register( [ __CLASS__, 'autoload' ] );
	}

	public static function autoload( string $class ): void {
		if ( strpos( $class, 'BlogAI_Pro\\' ) !== 0 ) {
			return;
		}

		$relative = substr( $class, strlen( 'BlogAI_Pro\\' ) );
		$parts    = explode( '\\', $relative );
		$file     = array_pop( $parts );

		// Ex: BlogAI_Pro\Modules\API\Client -> modules/API/class-client.php
		$file_name = 'class-' . strtolower( str_replace( '_', '-', $file ) ) . '.php';

		// Primeiro nível: Includes -> includes/ ; Modules\X -> modules/X/
		$dir_map = [
			'Includes' => 'includes/',
			'Modules'  => 'modules/',
		];

		$root = array_shift( $parts );
		if ( ! isset( $dir_map[ $root ] ) ) {
			return;
		}

		$sub_path = implode( '/', $parts );
		$sub_path = $sub_path ? $sub_path . '/' : '';

		$path = BLOGAI_PRO_PATH . $dir_map[ $root ] . $sub_path . $file_name;

		if ( file_exists( $path ) ) {
			require_once $path;
		}
	}
}
