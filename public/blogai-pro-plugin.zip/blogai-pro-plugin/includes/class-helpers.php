<?php
/**
 * Helpers reutilizáveis.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Helpers {

	public static function get_setting( string $key, mixed $default = null ): mixed {
		$settings = get_option( 'blogai_pro_settings', [] );
		return $settings[ $key ] ?? $default;
	}

	public static function update_setting( string $key, mixed $value ): void {
		$settings         = get_option( 'blogai_pro_settings', [] );
		$settings[ $key ] = $value;
		update_option( 'blogai_pro_settings', $settings );
	}

	public static function view( string $view, array $data = [] ): void {
		$file = BLOGAI_PRO_PATH . 'admin/views/' . $view . '.php';
		if ( ! file_exists( $file ) ) {
			return;
		}
		extract( $data, EXTR_SKIP ); // phpcs:ignore
		include $file;
	}

	public static function current_user_can_manage(): bool {
		return current_user_can( 'manage_options' );
	}

	public static function log( string $message, array $context = [] ): void {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[BlogAI Pro] ' . $message . ' ' . wp_json_encode( $context ) );
		}
	}
}
