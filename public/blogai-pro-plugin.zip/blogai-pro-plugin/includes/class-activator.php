<?php
/**
 * Ações executadas na ativação do plugin.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Activator {

	public static function activate(): void {
		// Opções padrão.
		$defaults = [
			'api_base_url'      => BLOGAI_PRO_API_BASE_URL,
			'default_status'    => 'draft',
			'default_category'  => 0,
			'seo_integration'   => 'auto', // auto | yoast | rankmath | none
			'auto_featured'     => 1,
			'plugin_version'    => BLOGAI_PRO_VERSION,
		];

		if ( ! get_option( 'blogai_pro_settings' ) ) {
			add_option( 'blogai_pro_settings', $defaults );
		}

		// Agenda evento de sincronização diário.
		if ( ! wp_next_scheduled( 'blogai_pro_sync_library' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'blogai_pro_sync_library' );
		}

		// Agenda renovação de token.
		if ( ! wp_next_scheduled( 'blogai_pro_refresh_token' ) ) {
			wp_schedule_event( time() + 10 * MINUTE_IN_SECONDS, 'hourly', 'blogai_pro_refresh_token' );
		}

		flush_rewrite_rules();
	}
}
