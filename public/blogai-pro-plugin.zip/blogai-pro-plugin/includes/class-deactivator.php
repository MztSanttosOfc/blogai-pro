<?php
/**
 * Ações executadas na desativação do plugin.
 *
 * @package BlogAI_Pro
 */

namespace BlogAI_Pro\Includes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Deactivator {

	public static function deactivate(): void {
		wp_clear_scheduled_hook( 'blogai_pro_sync_library' );
		wp_clear_scheduled_hook( 'blogai_pro_refresh_token' );
		wp_clear_scheduled_hook( 'blogai_pro_publish_scheduled' );
		flush_rewrite_rules();
	}
}
