<?php
/**
 * Executado quando o plugin é desinstalado pelo WordPress.
 *
 * @package BlogAI_Pro
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Remove opções persistidas.
delete_option( 'blogai_pro_settings' );
delete_option( 'blogai_pro_auth_token' );
delete_option( 'blogai_pro_refresh_token' );
delete_option( 'blogai_pro_user' );
delete_option( 'blogai_pro_last_sync' );

// Remove eventos agendados remanescentes.
wp_clear_scheduled_hook( 'blogai_pro_sync_library' );
wp_clear_scheduled_hook( 'blogai_pro_refresh_token' );
wp_clear_scheduled_hook( 'blogai_pro_publish_scheduled' );
