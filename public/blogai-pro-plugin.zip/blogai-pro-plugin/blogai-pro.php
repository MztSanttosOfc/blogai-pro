<?php
/**
 * Plugin Name:       BlogAI Pro
 * Plugin URI:        https://monzart.com.br
 * Description:       Plugin oficial do BlogAI Pro para WordPress. Gere, gerencie e publique artigos com IA diretamente do seu painel.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      8.0
 * Author:            BlogAI Pro
 * Author URI:        https://monzart.com.br
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       blogai-pro
 * Domain Path:       /languages
 *
 * @package BlogAI_Pro
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// -----------------------------------------------------------------------------
// Constantes do plugin
// -----------------------------------------------------------------------------
define( 'BLOGAI_PRO_VERSION', '1.0.1' );
define( 'BLOGAI_PRO_FILE', __FILE__ );
define( 'BLOGAI_PRO_PATH', plugin_dir_path( __FILE__ ) );
define( 'BLOGAI_PRO_URL', plugin_dir_url( __FILE__ ) );
define( 'BLOGAI_PRO_BASENAME', plugin_basename( __FILE__ ) );
define( 'BLOGAI_PRO_API_BASE_URL', 'https://monzart.com.br/api/v1' );
define( 'BLOGAI_PRO_MIN_PHP', '8.0' );
define( 'BLOGAI_PRO_MIN_WP', '6.0' );

// -----------------------------------------------------------------------------
// Verificação de requisitos
// -----------------------------------------------------------------------------
if ( version_compare( PHP_VERSION, BLOGAI_PRO_MIN_PHP, '<' ) ) {
	add_action( 'admin_notices', function () {
		echo '<div class="notice notice-error"><p>' .
			esc_html__( 'BlogAI Pro requer PHP 8.0 ou superior.', 'blogai-pro' ) .
			'</p></div>';
	} );
	return;
}

// -----------------------------------------------------------------------------
// Autoloader PSR-4 simples para os módulos
// -----------------------------------------------------------------------------
require_once BLOGAI_PRO_PATH . 'includes/class-autoloader.php';
\BlogAI_Pro\Includes\Autoloader::register();

// -----------------------------------------------------------------------------
// Hooks de ativação, desativação e desinstalação
// -----------------------------------------------------------------------------
register_activation_hook( __FILE__, [ '\BlogAI_Pro\Includes\Activator', 'activate' ] );
register_deactivation_hook( __FILE__, [ '\BlogAI_Pro\Includes\Deactivator', 'deactivate' ] );

// -----------------------------------------------------------------------------
// Bootstrap
// -----------------------------------------------------------------------------
add_action( 'plugins_loaded', function () {
	load_plugin_textdomain( 'blogai-pro', false, dirname( BLOGAI_PRO_BASENAME ) . '/languages' );
	\BlogAI_Pro\Includes\Plugin::instance()->run();
} );
