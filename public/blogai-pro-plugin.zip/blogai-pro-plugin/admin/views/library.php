<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="wrap blogai-pro-wrap">
	<div class="blogai-pro-header">
		<h1><?php esc_html_e( 'Biblioteca', 'blogai-pro' ); ?></h1>
		<button id="blogai-pro-sync" class="button"><?php esc_html_e( 'Sincronizar agora', 'blogai-pro' ); ?></button>
	</div>

	<table class="wp-list-table widefat fixed striped">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Título', 'blogai-pro' ); ?></th>
				<th><?php esc_html_e( 'Status', 'blogai-pro' ); ?></th>
				<th><?php esc_html_e( 'Atualizado', 'blogai-pro' ); ?></th>
				<th><?php esc_html_e( 'Ações', 'blogai-pro' ); ?></th>
			</tr>
		</thead>
		<tbody id="blogai-pro-library-tbody">
			<tr><td colspan="4" class="blogai-pro-muted"><?php esc_html_e( 'Carregando...', 'blogai-pro' ); ?></td></tr>
		</tbody>
	</table>
</div>
