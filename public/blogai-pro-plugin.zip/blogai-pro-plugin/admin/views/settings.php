<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$settings = get_option( 'blogai_pro_settings', [] );
?>
<div class="wrap blogai-pro-wrap">
	<h1><?php esc_html_e( 'Configurações', 'blogai-pro' ); ?></h1>

	<form method="post" action="options.php" class="blogai-pro-card blogai-pro-form">
		<?php settings_fields( 'blogai_pro_settings_group' ); ?>

		<label>
			<span><?php esc_html_e( 'URL da API', 'blogai-pro' ); ?></span>
			<input type="url" name="blogai_pro_settings[api_base_url]" value="<?php echo esc_attr( $settings['api_base_url'] ?? BLOGAI_PRO_API_BASE_URL ); ?>" />
		</label>

		<label>
			<span><?php esc_html_e( 'Status padrão ao publicar', 'blogai-pro' ); ?></span>
			<select name="blogai_pro_settings[default_status]">
				<option value="draft" <?php selected( $settings['default_status'] ?? 'draft', 'draft' ); ?>><?php esc_html_e( 'Rascunho', 'blogai-pro' ); ?></option>
				<option value="publish" <?php selected( $settings['default_status'] ?? 'draft', 'publish' ); ?>><?php esc_html_e( 'Publicar', 'blogai-pro' ); ?></option>
			</select>
		</label>

		<label>
			<span><?php esc_html_e( 'Categoria padrão', 'blogai-pro' ); ?></span>
			<?php wp_dropdown_categories( [
				'name'             => 'blogai_pro_settings[default_category]',
				'selected'         => (int) ( $settings['default_category'] ?? 0 ),
				'show_option_none' => __( '— Nenhuma —', 'blogai-pro' ),
				'hide_empty'       => 0,
			] ); ?>
		</label>

		<label>
			<span><?php esc_html_e( 'Integração SEO', 'blogai-pro' ); ?></span>
			<select name="blogai_pro_settings[seo_integration]">
				<option value="auto" <?php selected( $settings['seo_integration'] ?? 'auto', 'auto' ); ?>><?php esc_html_e( 'Automático', 'blogai-pro' ); ?></option>
				<option value="yoast" <?php selected( $settings['seo_integration'] ?? '', 'yoast' ); ?>>Yoast SEO</option>
				<option value="rankmath" <?php selected( $settings['seo_integration'] ?? '', 'rankmath' ); ?>>Rank Math</option>
				<option value="none" <?php selected( $settings['seo_integration'] ?? '', 'none' ); ?>><?php esc_html_e( 'Nenhuma', 'blogai-pro' ); ?></option>
			</select>
		</label>

		<label class="blogai-pro-form__inline">
			<input type="checkbox" name="blogai_pro_settings[auto_featured]" value="1" <?php checked( ! empty( $settings['auto_featured'] ) ); ?> />
			<span><?php esc_html_e( 'Definir imagem destacada automaticamente', 'blogai-pro' ); ?></span>
		</label>

		<?php submit_button(); ?>
	</form>
</div>
