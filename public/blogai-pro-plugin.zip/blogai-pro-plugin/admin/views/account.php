<?php
/** @var array $user */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$user = $user ?? [];
?>
<div class="wrap blogai-pro-wrap">
	<h1><?php esc_html_e( 'Minha conta', 'blogai-pro' ); ?></h1>
	<div class="blogai-pro-card">
		<p><strong><?php esc_html_e( 'Nome:', 'blogai-pro' ); ?></strong> <?php echo esc_html( $user['name'] ?? '—' ); ?></p>
		<p><strong><?php esc_html_e( 'E-mail:', 'blogai-pro' ); ?></strong> <?php echo esc_html( $user['email'] ?? '—' ); ?></p>
		<p><strong><?php esc_html_e( 'Plano:', 'blogai-pro' ); ?></strong> <?php echo esc_html( $user['plan'] ?? '—' ); ?></p>
		<button id="blogai-pro-logout" class="button"><?php esc_html_e( 'Sair', 'blogai-pro' ); ?></button>
	</div>
</div>
