<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="wrap blogai-pro-wrap">
	<h1><?php esc_html_e( 'Gerador de Artigos', 'blogai-pro' ); ?></h1>

	<div class="blogai-pro-grid blogai-pro-grid--2">
		<form id="blogai-pro-generator-form" class="blogai-pro-card blogai-pro-form">
			<label>
				<span><?php esc_html_e( 'Tópico ou título', 'blogai-pro' ); ?></span>
				<input type="text" name="topic" required />
			</label>
			<label>
				<span><?php esc_html_e( 'Tom de voz', 'blogai-pro' ); ?></span>
				<select name="tone">
					<option value="profissional"><?php esc_html_e( 'Profissional', 'blogai-pro' ); ?></option>
					<option value="casual"><?php esc_html_e( 'Casual', 'blogai-pro' ); ?></option>
					<option value="tecnico"><?php esc_html_e( 'Técnico', 'blogai-pro' ); ?></option>
				</select>
			</label>
			<label>
				<span><?php esc_html_e( 'Idioma', 'blogai-pro' ); ?></span>
				<select name="language">
					<option value="pt-BR">Português (BR)</option>
					<option value="en-US">English (US)</option>
					<option value="es-ES">Español</option>
				</select>
			</label>
			<label>
				<span><?php esc_html_e( 'Tamanho', 'blogai-pro' ); ?></span>
				<select name="length">
					<option value="short"><?php esc_html_e( 'Curto', 'blogai-pro' ); ?></option>
					<option value="medium" selected><?php esc_html_e( 'Médio', 'blogai-pro' ); ?></option>
					<option value="long"><?php esc_html_e( 'Longo', 'blogai-pro' ); ?></option>
				</select>
			</label>
			<button type="submit" class="button button-primary button-hero">
				<?php esc_html_e( 'Gerar artigo', 'blogai-pro' ); ?>
			</button>
		</form>

		<div class="blogai-pro-card">
			<h2><?php esc_html_e( 'Prévia', 'blogai-pro' ); ?></h2>
			<div id="blogai-pro-preview" class="blogai-pro-preview">
				<p class="blogai-pro-muted"><?php esc_html_e( 'A prévia do artigo aparecerá aqui após a geração.', 'blogai-pro' ); ?></p>
			</div>

			<div id="blogai-pro-preview-actions" class="blogai-pro-actions" hidden>
				<button type="button" class="button" data-action="draft"><?php esc_html_e( 'Salvar como rascunho', 'blogai-pro' ); ?></button>
				<button type="button" class="button button-primary" data-action="publish"><?php esc_html_e( 'Publicar agora', 'blogai-pro' ); ?></button>
				<button type="button" class="button" data-action="schedule"><?php esc_html_e( 'Agendar', 'blogai-pro' ); ?></button>
			</div>
		</div>
	</div>
</div>
