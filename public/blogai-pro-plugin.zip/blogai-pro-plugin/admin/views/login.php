<?php
/**
 * View de login — e-mail e senha (padrão) com opção de API Key.
 *
 * @package BlogAI_Pro
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="wrap blogai-pro-wrap blogai-pro-login">
	<div class="blogai-pro-card blogai-pro-card--auth">
		<div class="blogai-pro-brand">
			<span class="blogai-pro-brand__logo">BlogAI</span>
			<span class="blogai-pro-brand__pro">Pro</span>
		</div>
		<h1><?php esc_html_e( 'Entrar no BlogAI Pro', 'blogai-pro' ); ?></h1>
		<p class="blogai-pro-muted">
			<?php esc_html_e( 'Use a mesma conta do site monzart.com.br para conectar este WordPress.', 'blogai-pro' ); ?>
		</p>

		<div class="blogai-pro-tabs" role="tablist">
			<button type="button" class="blogai-pro-tab is-active" data-target="login-password" role="tab" aria-selected="true">
				<?php esc_html_e( 'E-mail e senha', 'blogai-pro' ); ?>
			</button>
			<button type="button" class="blogai-pro-tab" data-target="login-api-key" role="tab" aria-selected="false">
				<?php esc_html_e( 'API Key', 'blogai-pro' ); ?>
			</button>
		</div>

		<form id="blogai-pro-login-form" class="blogai-pro-form" data-tab="login-password" novalidate>
			<?php wp_nonce_field( 'blogai_pro_login', 'blogai_pro_nonce' ); ?>
			<input type="hidden" name="mode" value="password" />
			<label>
				<span><?php esc_html_e( 'E-mail', 'blogai-pro' ); ?></span>
				<input type="email" name="email" required autocomplete="username" />
			</label>
			<label>
				<span><?php esc_html_e( 'Senha', 'blogai-pro' ); ?></span>
				<input type="password" name="password" required autocomplete="current-password" />
			</label>
			<button type="submit" class="button button-primary button-hero">
				<?php esc_html_e( 'Entrar', 'blogai-pro' ); ?>
			</button>
			<p class="blogai-pro-form__hint">
				<a href="https://monzart.com.br/signup" target="_blank" rel="noopener noreferrer">
					<?php esc_html_e( 'Criar uma conta gratuita', 'blogai-pro' ); ?>
				</a>
			</p>
			<p class="blogai-pro-form__message" role="status" aria-live="polite"></p>
		</form>

		<form id="blogai-pro-login-form-key" class="blogai-pro-form" data-tab="login-api-key" hidden novalidate>
			<?php wp_nonce_field( 'blogai_pro_login_key', 'blogai_pro_nonce_key' ); ?>
			<input type="hidden" name="mode" value="api_key" />
			<label>
				<span><?php esc_html_e( 'API Key (bap_live_...)', 'blogai-pro' ); ?></span>
				<input type="password" name="api_key" required autocomplete="off" placeholder="bap_live_..." />
			</label>
			<button type="submit" class="button button-primary button-hero">
				<?php esc_html_e( 'Conectar', 'blogai-pro' ); ?>
			</button>
			<p class="blogai-pro-form__hint">
				<?php esc_html_e( 'Gere sua API Key em monzart.com.br → Desenvolvedor.', 'blogai-pro' ); ?>
			</p>
			<p class="blogai-pro-form__message" role="status" aria-live="polite"></p>
		</form>
	</div>
</div>
