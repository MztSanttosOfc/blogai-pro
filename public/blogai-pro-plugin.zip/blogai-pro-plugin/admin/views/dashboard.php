<?php
/** @var array $account */
if ( ! defined( 'ABSPATH' ) ) { exit; }
$account = $account ?? [];
?>
<div class="wrap blogai-pro-wrap">
	<div class="blogai-pro-header">
		<h1><?php esc_html_e( 'Dashboard', 'blogai-pro' ); ?></h1>
		<span class="blogai-pro-status blogai-pro-status--ok">
			<?php esc_html_e( 'Conectado', 'blogai-pro' ); ?>
		</span>
	</div>

	<div class="blogai-pro-grid blogai-pro-grid--4">
		<div class="blogai-pro-card">
			<span class="blogai-pro-card__label"><?php esc_html_e( 'Plano atual', 'blogai-pro' ); ?></span>
			<strong class="blogai-pro-card__value"><?php echo esc_html( $account['plan'] ?? '—' ); ?></strong>
		</div>
		<div class="blogai-pro-card">
			<span class="blogai-pro-card__label"><?php esc_html_e( 'Créditos disponíveis', 'blogai-pro' ); ?></span>
			<strong class="blogai-pro-card__value"><?php echo esc_html( number_format_i18n( (int) ( $account['credits'] ?? 0 ) ) ); ?></strong>
		</div>
		<div class="blogai-pro-card">
			<span class="blogai-pro-card__label"><?php esc_html_e( 'Artigos gerados', 'blogai-pro' ); ?></span>
			<strong class="blogai-pro-card__value"><?php echo esc_html( (string) ( $account['articles_generated'] ?? 0 ) ); ?></strong>
		</div>
		<div class="blogai-pro-card">
			<span class="blogai-pro-card__label"><?php esc_html_e( 'Artigos publicados', 'blogai-pro' ); ?></span>
			<strong class="blogai-pro-card__value"><?php echo esc_html( (string) ( $account['articles_published'] ?? 0 ) ); ?></strong>
		</div>
	</div>

	<div class="blogai-pro-card blogai-pro-card--wide">
		<h2><?php esc_html_e( 'Consumo de créditos', 'blogai-pro' ); ?></h2>
		<?php
		$used = (int) ( $account['credits_used'] ?? 0 );
		$total = $used + (int) ( $account['credits'] ?? 0 );
		$pct  = $total > 0 ? min( 100, round( $used * 100 / $total ) ) : 0;
		?>
		<div class="blogai-pro-progress">
			<div class="blogai-pro-progress__bar" style="width: <?php echo esc_attr( (string) $pct ); ?>%"></div>
		</div>
		<p class="blogai-pro-muted">
			<?php printf( esc_html__( '%1$s de %2$s créditos utilizados', 'blogai-pro' ), esc_html( (string) $used ), esc_html( (string) $total ) ); ?>
		</p>
	</div>
</div>
