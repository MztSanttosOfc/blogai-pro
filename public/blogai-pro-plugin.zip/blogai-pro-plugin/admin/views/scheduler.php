<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<div class="wrap blogai-pro-wrap">
	<h1><?php esc_html_e( 'Agendamentos', 'blogai-pro' ); ?></h1>
	<div class="blogai-pro-card">
		<p class="blogai-pro-muted"><?php esc_html_e( 'Nenhum agendamento futuro. Use o gerador ou a biblioteca para agendar uma publicação.', 'blogai-pro' ); ?></p>
	</div>
</div>
