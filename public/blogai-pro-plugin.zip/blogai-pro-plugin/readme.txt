=== BlogAI Pro ===
Contributors: blogaipro
Tags: ai, content, blogging, seo, generator, openai, publisher
Requires at least: 6.0
Tested up to: 6.6
Requires PHP: 8.0
Stable tag: 1.0.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Plugin oficial do BlogAI Pro para WordPress. Gere, gerencie e publique artigos com IA direto do painel.

== Description ==

Cliente oficial da API do BlogAI Pro (monzart.com.br). Toda a inteligência permanece no BlogAI Pro — o plugin apenas consome a API oficial e publica no WordPress.

Recursos:

* Login com **e-mail e senha** da sua conta BlogAI Pro (renovação automática de token).
* Alternativa por **API Key** (bap_live_...) para integrações e sites headless.
* Dashboard com plano, créditos e histórico.
* Gerador de artigos com IA.
* Biblioteca sincronizada com o BlogAI Pro (cache diário via cron).
* Publicação **nativa no WordPress** (post real, com imagem destacada, categorias, tags e SEO delegado ao Yoast/RankMath quando presente).
* Agendamento de publicações.
* Painel de desempenho (SEO Search Console).

Requer uma conta ativa em https://monzart.com.br.

== Installation ==

1. Envie a pasta `blogai-pro` para `/wp-content/plugins/` (ou instale via ZIP).
2. Ative pelo menu **Plugins**.
3. Acesse **BlogAI Pro → Dashboard** e faça login com o seu e-mail e senha.

== Frequently Asked Questions ==

= Preciso de uma conta paga? =
Não. O plano gratuito do BlogAI Pro já permite usar o plugin. Recursos avançados (créditos maiores, ilimitado) exigem um plano pago.

= Meus dados são enviados ao BlogAI Pro? =
Somente o que é necessário para gerar/publicar cada artigo (título, tópico, tokens de configuração). O plugin **não** envia conteúdo de outros posts nem dados de leitores.

= Como o token é armazenado? =
Como opção do WordPress (`wp_options`) restrita a administradores. O refresh é feito automaticamente a cada hora via WP-Cron.

== Screenshots ==

1. Tela de login (e-mail e senha).
2. Dashboard com plano e créditos.
3. Gerador de artigos.
4. Biblioteca com sincronização.

== Changelog ==

= 1.0.1 =
* Login por e-mail e senha (POST /api/v1/auth/login).
* Refresh automático de token (POST /api/v1/auth/refresh) via WP-Cron + interceptador de 401.
* Modo alternativo por API Key (bap_live_...).
* Publisher nativo: publicação como post do WordPress com imagem destacada, categoria, tags e SEO.
* JS refatorado sem `innerHTML` de dados dinâmicos (mitigação XSS).
* Arquivo .pot inicial em `languages/blogai-pro.pot`.
* WordPress Coding Standards (indentação com TAB, escape em todas as views).

= 1.0.0 =
* Versão inicial com arquitetura modular integrada à API oficial (Bearer manual).

== Upgrade Notice ==

= 1.0.1 =
Login com e-mail e senha + refresh automático + Publisher nativo. Recomendado para todos.
